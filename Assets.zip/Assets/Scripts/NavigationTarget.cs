using UnityEngine;

public class NavigationTarget : MonoBehaviour
{

}
